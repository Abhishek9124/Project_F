This feature has been removed as the application is now a single-page experience that does not persist data.
