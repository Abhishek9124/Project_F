
import { GoogleGenAI, Type, Modality } from "@google/genai";

// --- PERSISTENCE & AUDIT ---
const DB_KEY = 'CLARA_ENT_DB_V3';
const AUDIT_KEY = 'CLARA_AUDIT_V3';

const saveState = (patients) => localStorage.setItem(DB_KEY, JSON.stringify(patients));
const saveAudit = (log) => localStorage.setItem(AUDIT_KEY, JSON.stringify(log));

const loadState = () => {
    try {
        const data = localStorage.getItem(DB_KEY);
        return data ? JSON.parse(data) : [];
    } catch (e) { return []; }
};

const loadAudit = () => {
    try {
        const data = localStorage.getItem(AUDIT_KEY);
        return data ? JSON.parse(data) : [];
    } catch (e) { return []; }
};

function logEvent(action, resource, category = 'Success') {
    const log = loadAudit();
    const event = {
        timestamp: new Date().toISOString(),
        id: Math.random().toString(36).substr(2, 9).toUpperCase(),
        action,
        resource,
        category 
    };
    log.unshift(event);
    saveAudit(log.slice(0, 100));
    const auditView = document.getElementById('view-audit');
    if (auditView && !auditView.classList.contains('hidden')) {
        renderAuditLog();
    }
}

// --- BASE64 UTILS (Guidelines Compliant) ---
function encode(bytes) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// --- APP STATE ---
let state = {
    view: 'dashboard',
    patients: loadState(),
    activePatientId: null,
    isRecording: false,
    liveSession: null,
    audioContext: null,
    darkMode: localStorage.getItem('theme') === 'dark',
    charts: {},
    assistantChat: null,
    nextStartTime: 0,
    sources: new Set()
};

// --- SCHEMAS ---
const CLARA_SCHEMA = {
    type: Type.OBJECT,
    properties: {
        summary: { type: Type.STRING },
        differential_diagnoses: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    condition: { type: Type.STRING },
                    probability: { type: Type.STRING },
                    reasoning: { type: Type.STRING }
                },
                required: ["condition", "probability", "reasoning"]
            }
        },
        icd10_codes: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    code: { type: Type.STRING },
                    description: { type: Type.STRING }
                },
                required: ["code", "description"]
            }
        },
        risk: {
            type: Type.OBJECT,
            properties: {
                score: { type: Type.INTEGER },
                level: { type: Type.STRING },
                analysis: { type: Type.STRING }
            },
            required: ["score", "level", "analysis"]
        },
        predictive_insight: { type: Type.STRING },
        recommendations: { 
            type: Type.ARRAY, 
            items: { 
                type: Type.OBJECT,
                properties: {
                    id: { type: Type.STRING },
                    action: { type: Type.STRING },
                    rationale: { type: Type.STRING },
                    supervision_note: { type: Type.STRING }
                },
                required: ["id", "action", "rationale", "supervision_note"]
            } 
        },
        interventions: { type: Type.ARRAY, items: { type: Type.STRING } }
    },
    required: ["summary", "differential_diagnoses", "icd10_codes", "risk", "recommendations", "interventions", "predictive_insight"]
};

// --- CHART UTILITIES ---
function initChart(id, type, data, options) {
    const el = document.getElementById(id);
    if (!el) return;
    if (state.charts[id]) state.charts[id].destroy();
    const ctx = el.getContext('2d');
    state.charts[id] = new Chart(ctx, { type, data, options });
}

// --- CORE FUNCTIONS ---
window.setView = (view) => {
    state.view = view;
    document.querySelectorAll('main > div').forEach(d => d.classList.add('hidden'));
    const target = document.getElementById(`view-${view}`);
    if (target) target.classList.remove('hidden');
    
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.getElementById(`nav-${view}`)?.classList.add('active');

    if (view === 'dashboard') updateDashboard();
    if (view === 'patients') renderPatientRegistry();
    if (view === 'analytics') renderAnalyticsView();
    if (view === 'audit') renderAuditLog();
};

function updateDashboard() {
    const total = state.patients.length;
    const finalized = state.patients.filter(p => p.deployed).length;
    const avgRisk = total ? Math.round(state.patients.reduce((acc, curr) => acc + (curr.risk || 0), 0) / total) : 0;
    const needsReview = state.patients.filter(p => p.status === 'Needs Review').length;

    const els = {
        'stat-total-patients': total,
        'stat-active-encounters': needsReview,
        'stat-avg-risk': `${avgRisk}%`,
        'stat-deployments': finalized
    };

    Object.entries(els).forEach(([id, val]) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val;
    });

    renderActivityTable();
    renderTrendingDiagnoses();
}

function renderActivityTable() {
    const tbody = document.getElementById('patient-table-body');
    if (!tbody) return;
    tbody.innerHTML = state.patients.slice(-5).reverse().map(p => `
        <tr class="border-b hover:bg-zinc-50/50 dark:hover:bg-zinc-800 transition-all cursor-pointer" onclick="window.viewPatient('${p.id}')">
            <td class="px-6 py-4">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-700 font-bold text-xs">${p.name[0]}</div>
                    <div><span class="font-bold block">${p.name}</span><span class="text-[10px] text-zinc-400">#${p.id}</span></div>
                </div>
            </td>
            <td class="px-6 py-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase ${p.status === 'Stable' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}">${p.status}</span></td>
            <td class="px-6 py-4 font-bold text-zinc-500">${p.risk || 0}%</td>
            <td class="px-6 py-4 font-bold text-blue-600">Open</td>
        </tr>
    `).join('');
}

function renderTrendingDiagnoses() {
    const codes = state.patients.flatMap(p => p.analysis?.icd10_codes || []);
    const counts = codes.reduce((acc, c) => { acc[c.code] = (acc[c.code] || 0) + 1; return acc; }, {});
    const trending = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 5);
    const list = document.getElementById('trending-list');
    if (!list) return;
    list.innerHTML = trending.map(([code, count]) => `
        <div class="flex justify-between items-center p-2 bg-zinc-50 dark:bg-zinc-800 rounded border dark:border-zinc-700">
            <span class="font-mono text-xs font-bold text-blue-600">${code}</span>
            <span class="text-[10px] font-black bg-zinc-200 dark:bg-zinc-700 px-1.5 rounded">${count} Pts</span>
        </div>
    `).join('') || '<p class="text-xs text-zinc-400 italic">No trending data yet.</p>';
}

function renderAuditLog() {
    const tbody = document.getElementById('audit-log-body');
    if (!tbody) return;
    const logs = loadAudit();
    tbody.innerHTML = logs.map(l => `
        <tr class="border-b dark:border-zinc-800">
            <td class="px-6 py-3 opacity-60">${new Date(l.timestamp).toLocaleTimeString()}</td>
            <td class="px-6 py-3 font-bold">${l.id}</td>
            <td class="px-6 py-3">${l.action}</td>
            <td class="px-6 py-3 text-blue-600">${l.resource}</td>
        </tr>
    `).join('');
}

function renderPatientRegistry() {
    const grid = document.getElementById('patient-grid');
    if (!grid) return;
    grid.innerHTML = state.patients.map(p => `
        <div class="glass-card p-6 hover:border-blue-500 transition-all cursor-pointer" onclick="window.viewPatient('${p.id}')">
            <div class="flex justify-between items-start mb-4">
                <div class="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center text-blue-700 font-bold">${p.name[0]}</div>
                <span class="text-[10px] font-black text-zinc-400 uppercase tracking-widest">${p.id}</span>
            </div>
            <h4 class="font-bold text-lg mb-1">${p.name}</h4>
            <p class="text-xs text-zinc-500 mb-4">${p.gender}, born ${new Date(p.dob).toLocaleDateString()}</p>
            <div class="flex items-center justify-between pt-4 border-t dark:border-zinc-700">
                 <span class="text-[10px] font-bold uppercase text-zinc-400">Risk: ${p.risk || 0}%</span>
                 <span class="px-2 py-0.5 rounded text-[9px] font-black uppercase ${p.status === 'Stable' ? 'bg-green-50 text-green-600' : 'bg-orange-50 text-orange-600'}">${p.status}</span>
            </div>
        </div>
    `).join('');
}

function renderAnalyticsView() {
    const pts = state.patients;
    const riskLevels = { Low: 0, Medium: 0, High: 0 };
    pts.forEach(p => {
        if (p.risk <= 30) riskLevels.Low++;
        else if (p.risk <= 70) riskLevels.Medium++;
        else riskLevels.High++;
    });
    initChart('chart-risk-dist', 'doughnut', {
        labels: ['Low', 'Medium', 'High'],
        datasets: [{ data: Object.values(riskLevels), backgroundColor: ['#34c759', '#ff9500', '#ff3b30'] }]
    }, { responsive: true, maintainAspectRatio: false });

    const codes = pts.flatMap(p => p.analysis?.icd10_codes || []);
    const counts = codes.reduce((acc, c) => { acc[c.code] = (acc[c.code] || 0) + 1; return acc; }, {});
    const sorted = Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,5);
    initChart('chart-diag-prev', 'bar', {
        labels: sorted.map(s => s[0]),
        datasets: [{ label: 'Cases', data: sorted.map(s => s[1]), backgroundColor: '#0071e3' }]
    }, { responsive: true, maintainAspectRatio: false });
}

// --- GLOBAL AI ASSISTANT ---
async function sendAssistantMessage() {
    const inputEl = document.getElementById('ai-chat-input');
    const feed = document.getElementById('ai-chat-feed');
    const msg = inputEl?.value.trim();
    if (!msg) return;

    // Append User Message
    feed.innerHTML += `
        <div class="patient-bubble p-4 max-w-lg self-end bg-blue-600 text-white ml-auto">
            <p class="text-sm">${msg}</p>
        </div>
    `;
    inputEl.value = "";
    feed.scrollTop = feed.scrollHeight;

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        if (!state.assistantChat) {
            state.assistantChat = ai.chats.create({
                model: 'gemini-3-pro-preview',
                config: {
                    systemInstruction: "You are CLARA, an AI health assistant. Help with triage, condition explaining, and coordination. Be medical but accessible. If triage looks urgent, suggest ER. Always clarify you are an AI. If requested to book, mock a booking process. Support multiple languages."
                }
            });
        }

        const response = await state.assistantChat.sendMessage({ message: msg });
        feed.innerHTML += `
            <div class="assistant-bubble p-4 max-w-lg mr-auto">
                <p class="text-sm">${response.text}</p>
            </div>
        `;
        feed.scrollTop = feed.scrollHeight;
    } catch (e) {
        console.error(e);
        feed.innerHTML += `<div class="p-2 text-red-500 text-xs text-center">Chat Error. Check Connection.</div>`;
    }
}
window.sendAssistantMessage = sendAssistantMessage;

// --- LIVE AUDIO TRANSCRIPTION ---
async function startRecording() {
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        state.audioContext = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
        const source = state.audioContext.createMediaStreamSource(stream);
        const scriptProcessor = state.audioContext.createScriptProcessor(4096, 1, 1);
        
        let transcriptBuffer = "";
        
        const sessionPromise = ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            callbacks: {
                onopen: () => {
                    logEvent('LIVE_TRANSCRIPTION_START', state.activePatientId);
                    state.isRecording = true;
                    document.getElementById('live-indicator')?.classList.remove('hidden');
                },
                onmessage: (msg) => {
                    if (msg.serverContent?.inputTranscription) {
                        transcriptBuffer += msg.serverContent.inputTranscription.text;
                    }
                    if (msg.serverContent?.turnComplete) {
                        const final = transcriptBuffer.trim();
                        if (final) {
                            const p = state.patients.find(pt => pt.id === state.activePatientId);
                            if (p) {
                                if (!p.encounters) p.encounters = [];
                                // Heuristic: detect if speaker sounds like a provider
                                const isDoctor = final.toLowerCase().includes('how can i') || 
                                               final.toLowerCase().includes('prescribe') ||
                                               final.toLowerCase().includes('medical history');
                                p.encounters.push({ speaker: isDoctor ? 'Doctor' : 'Patient', text: final, ts: Date.now() });
                                saveState(state.patients);
                                renderTranscript();
                            }
                        }
                        transcriptBuffer = "";
                    }
                },
                onerror: (err) => {
                    console.error("Live Audio Error:", err);
                    logEvent('LIVE_TRANSCRIPTION_ERROR', state.activePatientId, 'Error');
                    stopRecording();
                },
                onclose: () => {
                    state.isRecording = false;
                    document.getElementById('live-indicator')?.classList.add('hidden');
                }
            },
            config: {
                responseModalities: [Modality.AUDIO],
                inputAudioTranscription: {},
                systemInstruction: "Capture medical dialogues. Differentiate between patient symptoms and clinical instructions."
            }
        });

        scriptProcessor.onaudioprocess = (e) => {
            if (!state.isRecording) return;
            const input = e.inputBuffer.getChannelData(0);
            const int16 = new Int16Array(input.length);
            for (let i = 0; i < input.length; i++) {
                int16[i] = Math.max(-1, Math.min(1, input[i])) * 0x7FFF;
            }
            const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000'
            };
            sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
        };

        source.connect(scriptProcessor);
        scriptProcessor.connect(state.audioContext.destination);
        state.liveSession = await sessionPromise;
        
    } catch (e) {
        console.error(e);
        alert("Microphone access denied.");
    }
}

function stopRecording() {
    if (state.liveSession) state.liveSession.close();
    if (state.audioContext) state.audioContext.close();
    state.isRecording = false;
    document.getElementById('live-indicator')?.classList.add('hidden');
    saveState(state.patients);
}

// --- Vitals & Patient Utils ---
function renderVitalsPane() {
    const p = state.patients.find(pt => pt.id === state.activePatientId);
    if (!p) return;
    const historyList = document.getElementById('vitals-history-list');
    const vitals = p.vitals || [];
    
    historyList.innerHTML = vitals.slice(-10).reverse().map(v => `
        <div class="flex justify-between items-center p-3 bg-white dark:bg-zinc-800 rounded border dark:border-zinc-700 text-xs shadow-sm">
            <div class="flex gap-4">
                <span><b>BP:</b> ${v.systolic}/${v.diastolic}</span>
                <span><b>HR:</b> ${v.hr}</span>
                <span><b>Pain:</b> ${v.pain}/10</span>
            </div>
            <span class="text-[10px] text-zinc-400">${new Date(v.ts).toLocaleTimeString()}</span>
        </div>
    `).join('') || '<p class="text-center py-10 text-zinc-400 text-xs">No entries.</p>';

    if (vitals.length > 0) {
        initChart('chart-vitals-trend', 'line', {
            labels: vitals.slice(-10).map(v => new Date(v.ts).toLocaleTimeString()),
            datasets: [
                { label: 'Systolic', data: vitals.slice(-10).map(v => v.systolic), borderColor: '#0071e3', tension: 0.4 },
                { label: 'Pain', data: vitals.slice(-10).map(v => v.pain), borderColor: '#ff3b30', tension: 0.4 }
            ]
        }, { responsive: true, maintainAspectRatio: false });
    }
}

function renderTranscript() {
    const p = state.patients.find(pt => pt.id === state.activePatientId);
    const feed = document.getElementById('transcript-feed');
    if (!p || !feed) return;
    feed.innerHTML = (p.encounters || []).map(e => `
        <div class="transcript-bubble ${e.speaker === 'Doctor' ? 'doctor-bubble' : 'patient-bubble'}">
            <span class="text-[9px] font-black uppercase block mb-1 opacity-70">${e.speaker}</span>
            <p>${e.text}</p>
        </div>
    `).join('') || '<p class="text-center py-20 opacity-30 text-xs uppercase font-black">No dialogue recorded.</p>';
    feed.scrollTop = feed.scrollHeight;
}

// --- FACILITY SEARCH (MAPS) ---
window.findNearbyFacilities = async () => {
    const p = state.patients.find(pt => pt.id === state.activePatientId);
    if (!p || !p.analysis) return;
    const btn = document.querySelector('[onclick="window.findNearbyFacilities()"]');
    const container = document.getElementById('nearby-facilities-list');
    
    btn.disabled = true;
    btn.innerText = "Searching...";
    
    try {
        const pos = await new Promise((res, rej) => navigator.geolocation.getCurrentPosition(res, rej));
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const condition = p.analysis.differential_diagnoses[0]?.condition || "general practitioner";
        
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-latest",
            contents: `Identify top specialized clinics or hospitals near me for: ${condition}. Suggest facilities based on patient symptoms: ${p.encounters?.map(e => e.text).join(' ')}.`,
            config: {
                tools: [{googleMaps: {}}],
                toolConfig: { retrievalConfig: { latLng: { latitude: pos.coords.latitude, longitude: pos.coords.longitude } } }
            }
        });

        const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
        container.innerHTML = chunks.map(c => {
            if (!c.maps) return '';
            return `
                <a href="${c.maps.uri}" target="_blank" class="block p-3 bg-white dark:bg-zinc-800 border rounded-xl hover:border-blue-500 shadow-sm transition-all group">
                    <div class="flex justify-between items-center">
                        <span class="font-bold text-sm text-blue-700 dark:text-blue-400 group-hover:text-blue-600">${c.maps.title}</span>
                        <svg class="w-4 h-4 text-zinc-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                    </div>
                </a>
            `;
        }).join('') || `<p class="text-xs italic text-zinc-500 p-2">${response.text}</p>`;
        
    } catch (e) {
        alert("Search failed.");
    } finally {
        btn.disabled = false;
        btn.innerText = "Locate specialized care";
    }
};

// --- VIDEO GENERATION (VEO) ---
window.generatePatientVideoSummary = async () => {
    const p = state.patients.find(pt => pt.id === state.activePatientId);
    if (!p || !p.analysis) return;

    if (!(await window.aistudio.hasSelectedApiKey())) {
        await window.aistudio.openSelectKey();
    }

    const overlay = document.getElementById('video-loading-overlay');
    overlay.classList.remove('hidden');
    
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        let op = await ai.models.generateVideos({
            model: 'veo-3.1-fast-generate-preview',
            prompt: `Medical case brief for ${p.name}. Visualizing clinical metrics: ${p.analysis.summary}.`,
            config: { numberOfVideos: 1, resolution: '1080p', aspectRatio: '16:9' }
        });

        while (!op.done) {
            await new Promise(r => setTimeout(r, 10000));
            op = await ai.operations.getVideosOperation({ operation: op });
        }

        const link = op.response?.generatedVideos?.[0]?.video?.uri;
        const res = await fetch(`${link}&key=${process.env.API_KEY}`);
        const blob = await res.blob();
        p.videoUrl = URL.createObjectURL(blob);
        saveState(state.patients);
        window.renderVideoPane();
    } catch (e) {
        alert("Video generation failed.");
    } finally {
        overlay.classList.add('hidden');
    }
};

window.renderVideoPane = () => {
    const p = state.patients.find(pt => pt.id === state.activePatientId);
    const container = document.getElementById('video-content-container');
    if (!p || !container) return;

    if (p.videoUrl) {
        container.innerHTML = `
            <div class="glass-card p-6 space-y-4">
                <h3 class="text-xl font-bold">Case Visualization</h3>
                <video controls src="${p.videoUrl}" class="w-full rounded-2xl shadow-2xl"></video>
                <button onclick="window.generatePatientVideoSummary()" class="text-xs text-blue-600 font-bold">Regenerate</button>
            </div>
        `;
    } else {
        container.innerHTML = `
            <div class="glass-card p-20 flex flex-col items-center space-y-6">
                <h4 class="text-xl font-bold">Synthesize Video Brief</h4>
                <button onclick="window.generatePatientVideoSummary()" class="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold shadow-lg">Generate AI Briefing</button>
            </div>
        `;
    }
};

// --- ANALYSIS ---
async function runAnalysis() {
    const p = state.patients.find(pt => pt.id === state.activePatientId);
    if (!p || !p.encounters?.length) return;

    const btn = document.getElementById('btn-analyze');
    btn.disabled = true;
    btn.innerText = "Synthesizing...";

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
            model: "gemini-3-pro-preview",
            contents: `Analyze patient: ${p.name}. Vitals: ${JSON.stringify(p.vitals || [])}. Dialogue: ${p.encounters.map(e => e.text).join(' ')}.`,
            config: { responseMimeType: "application/json", responseSchema: CLARA_SCHEMA }
        });

        p.analysis = JSON.parse(response.text.trim());
        p.risk = p.analysis.risk.score;
        p.status = p.risk > 50 ? 'Needs Review' : 'Stable';
        saveState(state.patients);
        logEvent('CLINICAL_ANALYSIS', p.id);
        window.switchTab('analysis');
    } catch (e) { 
        alert("Analysis failed."); 
    } finally {
        btn.disabled = false;
        btn.innerText = "Synthesize Findings";
    }
}
window.runAnalysis = runAnalysis;

// --- EVENTS ---
document.getElementById('ai-chat-input')?.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') sendAssistantMessage();
});
document.getElementById('btn-send-ai-chat')?.addEventListener('click', sendAssistantMessage);

document.getElementById('btn-mic')?.addEventListener('click', () => {
  state.isRecording ? stopRecording() : startRecording();
});

document.getElementById('vitals-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const p = state.patients.find(pt => pt.id === state.activePatientId);
    if (!p) return;
    if (!p.vitals) p.vitals = [];
    p.vitals.push({
        systolic: parseInt(fd.get('systolic')),
        diastolic: parseInt(fd.get('diastolic')),
        hr: parseInt(fd.get('hr')),
        pain: parseInt(fd.get('pain')),
        ts: Date.now()
    });
    saveState(state.patients);
    renderVitalsPane();
    e.target.reset();
});

document.getElementById('intake-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const id = 'PT-' + Math.random().toString(36).substr(2, 4).toUpperCase();
    state.patients.push({ id, name: fd.get('name'), dob: fd.get('dob'), gender: fd.get('gender'), encounters: [], vitals: [], status: 'Draft', risk: 0 });
    saveState(state.patients);
    window.hideIntakeModal();
    window.viewPatient(id);
});

window.toggleDarkMode = () => {
    state.darkMode = !state.darkMode;
    document.body.classList.toggle('dark', state.darkMode);
    localStorage.setItem('theme', state.darkMode ? 'dark' : 'light');
    const thumb = document.getElementById('mode-toggle-thumb');
    if (thumb) thumb.style.transform = state.darkMode ? 'translateX(16px)' : 'translateX(0)';
};

window.showIntakeModal = () => document.getElementById('intake-modal').classList.remove('hidden');
window.hideIntakeModal = () => document.getElementById('intake-modal').classList.add('hidden');
window.clearChat = () => { document.getElementById('ai-chat-feed').innerHTML = ''; state.assistantChat = null; };

window.deployReport = () => {
    const p = state.patients.find(pt => pt.id === state.activePatientId);
    if (!p) return;
    p.deployed = true;
    saveState(state.patients);
    alert("Report Finalized.");
};

window.switchTab = (tab) => {
    document.querySelectorAll('#view-single-patient [id^="pane-"]').forEach(p => p.classList.add('hidden'));
    document.getElementById(`pane-${tab}`)?.classList.remove('hidden');
    document.querySelectorAll('#view-single-patient [id^="tab-"]').forEach(t => {
        t.className = 'px-4 py-1.5 rounded-md text-xs font-bold transition-all text-zinc-500';
    });
    const activeBtn = document.getElementById(`tab-${tab}`);
    if (activeBtn) activeBtn.className = 'px-4 py-1.5 rounded-md text-xs font-bold transition-all bg-white shadow-sm text-blue-600';
    
    if (tab === 'vitals') renderVitalsPane();
    if (tab === 'analysis') renderAnalysisPane();
    if (tab === 'video') window.renderVideoPane();
};

window.viewPatient = (id) => {
    state.activePatientId = id;
    const p = state.patients.find(pt => pt.id === id);
    if (!p) return;
    document.getElementById('active-p-name').innerText = p.name;
    document.getElementById('active-p-id').innerText = `#ID-${p.id}`;
    window.setView('single-patient');
    window.switchTab('encounter');
    renderTranscript();
};

// --- START ---
if (state.darkMode) document.body.classList.add('dark');
window.setView('dashboard');
